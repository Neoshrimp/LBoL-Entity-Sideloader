### Effect Library
*not a gameplay mod*

`0.0.11` the only SE is currently bugged. Don't use this

Commonly useful entity/effect library for modders.

Very small currently, if during mod dev something seems generically useful I might add it.

*Card Autoplay would be a great addition*

**The library**
```
SE:
  -NoDamageLimitSe: By passes damage reduction effects
```

### How to use

1. Reference `EffectLib.dll` in your mod project
2. Add `TeamNeo-EffectLib-0.0.1` dependency string to your `manifest.json`
3. Read Effect Lib source code.
4. Use entities as provided or extend abstract definition classes for customization.




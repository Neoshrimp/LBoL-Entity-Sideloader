Modding framework for working with LBoL entities.

#### Change log

`0.7.3` added dynamic template generation. Refer to [this](https://github.com/Neoshrimp/LBoL-Entity-Sideloader/blob/master/src/TermplateGenTests/Generation.cs) for an example.

`0.7.5` added template for Jade Boxes.

-------------------------------------

More info at [github repo](https://github.com/Neoshrimp/LBoL-Entity-Sideloader/tree/master)
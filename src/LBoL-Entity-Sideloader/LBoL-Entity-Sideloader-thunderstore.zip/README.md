Modding framework for working with LBoL entities.

More info at [github repo](https://github.com/Neoshrimp/LBoL-Entity-Sideloader/tree/master)